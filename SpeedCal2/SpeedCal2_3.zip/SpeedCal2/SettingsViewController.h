//
//  SettingsViewController.h
//  SpeedCal2
//
//  Created by Arnoldas on 8/10/13.
//  Copyright (c) 2013 moze. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsViewController : UITableViewController
- (IBAction)CloseButton:(id)sender;

@end
