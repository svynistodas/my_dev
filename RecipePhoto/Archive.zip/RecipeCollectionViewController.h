//
//  RecipeCollectionViewController.h
//  RecipePhoto
//
//  Created by Arnoldas on 9/14/13.
//  Copyright (c) 2013 moze. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DisplayImageViewController.h"

@interface RecipeCollectionViewController : UICollectionViewController

@end
